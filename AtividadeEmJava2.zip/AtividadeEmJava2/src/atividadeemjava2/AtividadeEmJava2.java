
package atividadeemjava2;
// Interface que define os estados da máquina de vendas
interface MaquinaVendaState {
    void inserirMoeda();
    void selecionarProduto();
    void dispensarProduto();
}

// Implementação do estado "Sem Moeda"
class SemMoedaState implements MaquinaVendaState {
    private MaquinaVenda maquina;

    public SemMoedaState(MaquinaVenda maquina) {
        this.maquina = maquina;
    }

    @Override
    public void inserirMoeda() {
        System.out.println("Moeda inserida. Você agora pode selecionar um produto.");
        maquina.setEstado(MaquinaVendaStateFactory.createComMoedaState(maquina));
    }

    @Override
    public void selecionarProduto() {
        System.out.println("Insira uma moeda antes de selecionar o produto.");
    }

    @Override
    public void dispensarProduto() {
        System.out.println("Primeiro insira uma moeda e selecione o produto.");
    }
}

// Implementação do estado "Com Moeda"
class ComMoedaState implements MaquinaVendaState {
    private MaquinaVenda maquina;

    public ComMoedaState(MaquinaVenda maquina) {
        this.maquina = maquina;
    }

    @Override
    public void inserirMoeda() {
        System.out.println("Moeda já inserida. Selecione o produto.");
    }

    @Override
    public void selecionarProduto() {
        System.out.println("Produto selecionado. Dispensando produto...");
        maquina.setEstado(MaquinaVendaStateFactory.createProdutoDispensoState(maquina));
    }

    @Override
    public void dispensarProduto() {
        System.out.println("Selecione o produto antes de dispensá-lo.");
    }
}

// Implementação do estado "Produto Dispenso"
class ProdutoDispensoState implements MaquinaVendaState {
    private MaquinaVenda maquina;

    public ProdutoDispensoState(MaquinaVenda maquina) {
        this.maquina = maquina;
    }

    @Override
    public void inserirMoeda() {
        System.out.println("Aguarde, dispensando o produto atual.");
    }

    @Override
    public void selecionarProduto() {
        System.out.println("Aguarde, dispensando o produto atual.");
    }

    @Override
    public void dispensarProduto() {
        System.out.println("Produto dispensado. Obrigado pela compra!");
        maquina.setEstado(MaquinaVendaStateFactory.createSemMoedaState(maquina));
    }
}

// Classe que representa a máquina de vendas
class MaquinaVenda {
    private MaquinaVendaState estadoAtual;

    public MaquinaVenda() {
        estadoAtual = MaquinaVendaStateFactory.createSemMoedaState(this);
    }

    public void setEstado(MaquinaVendaState novoEstado) {
        estadoAtual = novoEstado;
    }

    public void inserirMoeda() {
        estadoAtual.inserirMoeda();
    }

    public void selecionarProduto() {
        estadoAtual.selecionarProduto();
    }

    public void dispensarProduto() {
        estadoAtual.dispensarProduto();
    }
}

// Atualizando a fábrica para incluir o novo estado
class MaquinaVendaStateFactory {
    public static MaquinaVendaState createSemMoedaState(MaquinaVenda maquina) {
        return new SemMoedaState(maquina);
    }

    public static MaquinaVendaState createComMoedaState(MaquinaVenda maquina) {
        return new ComMoedaState(maquina);
    }

    public static MaquinaVendaState createProdutoDispensoState(MaquinaVenda maquina) {
        return new ProdutoDispensoState(maquina);
    }

    public static MaquinaVendaState createProdutoEsgotadoState(MaquinaVenda maquina) {
        return new ProdutoEsgotadoState(maquina);
    }
}


 class ProdutoEsgotadoState implements MaquinaVendaState {
    private MaquinaVenda maquina;

    public ProdutoEsgotadoState(MaquinaVenda maquina) {
        this.maquina = maquina;
    }

    @Override
    public void inserirMoeda() {
        System.out.println("Produto esgotado. Não é possível inserir moeda.");
    }

    @Override
    public void selecionarProduto() {
        System.out.println("Produto esgotado. Não é possível selecionar.");
    }

    @Override
    public void dispensarProduto() {
        System.out.println("Produto esgotado. Não há produto para dispensar.");
    }
}


public class AtividadeEmJava2 {

   
    public static void main(String[] args) {
MaquinaVenda maquina = new MaquinaVenda();

        maquina.inserirMoeda();
        maquina.selecionarProduto();
        maquina.dispensarProduto();

      

        maquina.inserirMoeda();
        maquina.inserirMoeda();
        maquina.selecionarProduto();
        maquina.dispensarProduto();    }
    
}
