
package atividadeemjava;

interface MaquinaVendaState {
    void inserirMoeda();
    void selecionarProduto();
    void dispensarProduto();
}

class SemMoedaState implements MaquinaVendaState {
    private MaquinaVenda maquina;

    public SemMoedaState(MaquinaVenda maquina) {
        this.maquina = maquina;
    }

    @Override
    public void inserirMoeda() {
        System.out.println("Moeda inserida. Você agora pode selecionar um produto.");
        maquina.setEstado(MaquinaVendaStateFactory.createComMoedaState(maquina));
    }

    @Override
    public void selecionarProduto() {
        System.out.println("Insira uma moeda antes de selecionar o produto.");
    }

    @Override
    public void dispensarProduto() {
        System.out.println("Primeiro insira uma moeda e selecione o produto.");
    }
}

class ComMoedaState implements MaquinaVendaState {
    private MaquinaVenda maquina;

    public ComMoedaState(MaquinaVenda maquina) {
        this.maquina = maquina;
    }

    @Override
    public void inserirMoeda() {
        System.out.println("Moeda já inserida. Selecione o produto.");
    }

    @Override
    public void selecionarProduto() {
        System.out.println("Produto selecionado. Dispensando produto...");
        maquina.setEstado(MaquinaVendaStateFactory.createProdutoDispensoState(maquina));
    }

    @Override
    public void dispensarProduto() {
        System.out.println("Selecione o produto antes de dispensá-lo.");
    }
}

class ProdutoDispensoState implements MaquinaVendaState {
    private MaquinaVenda maquina;

    public ProdutoDispensoState(MaquinaVenda maquina) {
        this.maquina = maquina;
    }

    @Override
    public void inserirMoeda() {
        System.out.println("Aguarde, dispensando o produto atual.");
    }

    @Override
    public void selecionarProduto() {
        System.out.println("Aguarde, dispensando o produto atual.");
    }

    @Override
    public void dispensarProduto() {
        System.out.println("Produto dispensado. Obrigado pela compra!");
        maquina.setEstado(MaquinaVendaStateFactory.createSemMoedaState(maquina));
    }
}

class MaquinaVenda {
    private MaquinaVendaState estadoAtual;

    public MaquinaVenda() {
        estadoAtual = MaquinaVendaStateFactory.createSemMoedaState(this);
    }

    public void setEstado(MaquinaVendaState novoEstado) {
        estadoAtual = novoEstado;
    }

    public void inserirMoeda() {
        estadoAtual.inserirMoeda();
    }

    public void selecionarProduto() {
        estadoAtual.selecionarProduto();
    }

    public void dispensarProduto() {
        estadoAtual.dispensarProduto();
    }
}

class MaquinaVendaStateFactory {
    public static MaquinaVendaState createSemMoedaState(MaquinaVenda maquina) {
        return new SemMoedaState(maquina);
    }

    public static MaquinaVendaState createComMoedaState(MaquinaVenda maquina) {
        return new ComMoedaState(maquina);
    }

    public static MaquinaVendaState createProdutoDispensoState(MaquinaVenda maquina) {
        return new ProdutoDispensoState(maquina);
    }
}


public class AtividadeEmJava {

    
    public static void main(String[] args) {
        MaquinaVenda maquina = new MaquinaVenda();

        maquina.inserirMoeda();
        maquina.selecionarProduto();
        maquina.dispensarProduto();

        

        maquina.inserirMoeda();
        maquina.inserirMoeda();
        maquina.selecionarProduto();
        maquina.dispensarProduto();
    }
    
}
